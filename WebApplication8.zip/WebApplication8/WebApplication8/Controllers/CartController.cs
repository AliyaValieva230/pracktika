﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication8.Data;
using WebApplication8.Models;
using System.Security.Claims;
using System.Text.Json;

namespace WebApplication8.Controllers
{
    public class CartController : Controller
    {
        private readonly JewelryStoreContext _context;

        public CartController(JewelryStoreContext context)
        {
            _context = context;
        }

        
        public async Task<IActionResult> Index()
        {
            var userId = GetCurrentUserId();
            if (userId == null)
            {
                
                var cartItems = GetCartFromSession();
                return View(cartItems);
            }

            var items = await _context.Cart
                .Include(c => c.Product)
                .ThenInclude(p => p.Images)
                .Where(c => c.UserId == userId)
                .ToListAsync();

            return View(items);
        }

        
        [HttpPost]
        public async Task<IActionResult> AddToCart(int productId, int quantity = 1)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null || product.StockQuantity < quantity)
            {
                TempData["Error"] = "Товар недоступен в нужном количестве.";
                return RedirectToAction("ProductDetails", "Home", new { id = productId });
            }

            var userId = GetCurrentUserId();
            if (userId != null)
            {
                
                var cartItem = await _context.Cart
                    .FirstOrDefaultAsync(c => c.UserId == userId && c.ProductId == productId);

                if (cartItem != null)
                {
                    cartItem.Quantity += quantity;
                }
                else
                {
                    cartItem = new Cart
                    {
                        UserId = userId.Value,
                        ProductId = productId,
                        Quantity = quantity
                    };
                    _context.Cart.Add(cartItem);
                }
                await _context.SaveChangesAsync();
            }
            else
            {
                
                AddToCartSession(productId, quantity);
            }

            TempData["Success"] = "Товар добавлен в корзину.";
            return RedirectToAction("ProductDetails", "Home", new { id = productId });
        }

        
        [HttpPost]
        public async Task<IActionResult> UpdateQuantity(int cartId, int quantity)
        {
            var userId = GetCurrentUserId();
            if (userId != null)
            {
                var cartItem = await _context.Cart.FindAsync(cartId);
                if (cartItem != null && cartItem.UserId == userId)
                {
                    cartItem.Quantity = quantity;
                    await _context.SaveChangesAsync();
                }
            }
            else
            {
                UpdateCartSession(cartId, quantity);
            }
            return RedirectToAction("Index");
        }

        
        [HttpPost]
        public async Task<IActionResult> RemoveFromCart(int cartId)
        {
            var userId = GetCurrentUserId();
            if (userId != null)
            {
                var cartItem = await _context.Cart.FindAsync(cartId);
                if (cartItem != null && cartItem.UserId == userId)
                {
                    _context.Cart.Remove(cartItem);
                    await _context.SaveChangesAsync();
                }
            }
            else
            {
                RemoveFromCartSession(cartId);
            }
            return RedirectToAction("Index");
        }

        
        private List<Cart> GetCartFromSession()
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<Cart>>("Cart") ?? new List<Cart>();
            
            foreach (var item in cart)
            {
                item.Product = _context.Products.Include(p => p.Images).FirstOrDefault(p => p.ProductId == item.ProductId);
            }
            return cart;
        }

        private void AddToCartSession(int productId, int quantity)
        {
            var cart = GetCartFromSession();
            var existing = cart.FirstOrDefault(c => c.ProductId == productId);
            if (existing != null)
                existing.Quantity += quantity;
            else
                cart.Add(new Cart { ProductId = productId, Quantity = quantity, CartId = cart.Count + 1 }); // временный id
            HttpContext.Session.SetObjectAsJson("Cart", cart);
        }

        private void UpdateCartSession(int cartId, int quantity)
        {
            var cart = GetCartFromSession();
            var item = cart.FirstOrDefault(c => c.CartId == cartId);
            if (item != null)
                item.Quantity = quantity;
            HttpContext.Session.SetObjectAsJson("Cart", cart);
        }

        private void RemoveFromCartSession(int cartId)
        {
            var cart = GetCartFromSession();
            var item = cart.FirstOrDefault(c => c.CartId == cartId);
            if (item != null)
                cart.Remove(item);
            HttpContext.Session.SetObjectAsJson("Cart", cart);
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
                return userId;
            return null;
        }
    }
}


public static class SessionExtensions
{
    public static void SetObjectAsJson(this ISession session, string key, object value)
    {
        session.SetString(key, JsonSerializer.Serialize(value));
    }

    public static T GetObjectFromJson<T>(this ISession session, string key)
    {
        var value = session.GetString(key);
        return value == null ? default : JsonSerializer.Deserialize<T>(value);
    }
}