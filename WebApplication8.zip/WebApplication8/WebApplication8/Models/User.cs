﻿using System.ComponentModel.DataAnnotations;
using WebApplication8.Models;

public class User
{
    public int UserId { get; set; }
    [Required, EmailAddress]
    public string Email { get; set; }
    [Required]
    public string PasswordHash { get; set; }
    [Required]
    public string FullName { get; set; }
    [Phone]
    public string? Phone { get; set; }   
    public string Role { get; set; } = "User";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public bool IsActive { get; set; } = true;
    public ICollection<Cart> CartItems { get; set; }
    public ICollection<Order> Orders { get; set; }
}