﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication8.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        public int CategoryId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required, DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public int StockQuantity { get; set; }

        public Category Category { get; set; }
        public ICollection<ProductImage> Images { get; set; }
        public ICollection<ProductAttribute> Attributes { get; set; }
        public ICollection<Cart> CartItems { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; }
    }
}