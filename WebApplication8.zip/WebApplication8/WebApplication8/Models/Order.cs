﻿using System.ComponentModel.DataAnnotations;
using WebApplication8.Models;

public class Order
{
    public int OrderId { get; set; }
    public int UserId { get; set; }
    [Required]
    public string OrderNumber { get; set; }
    public DateTime OrderDate { get; set; } = DateTime.Now;
    public decimal TotalAmount { get; set; }
    public string? Status { get; set; } = "Pending";   
    public User User { get; set; }
    public ICollection<OrderItem> OrderItems { get; set; }
}