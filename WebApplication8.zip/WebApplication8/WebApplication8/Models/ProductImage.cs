﻿using System.ComponentModel.DataAnnotations;
using WebApplication8.Models;

public class ProductImage
{
    [Key]
    public int ImageId { get; set; }
    public int ProductId { get; set; }
    public string? ImageUrl { get; set; }   
    public Product Product { get; set; }
}