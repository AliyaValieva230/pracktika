﻿using System.ComponentModel.DataAnnotations;
using WebApplication8.Models;

public class ProductAttribute
{
    [Key]
    public int AttributeId { get; set; }
    public int ProductId { get; set; }
    public string? AttributeName { get; set; }   
    public string? AttributeValue { get; set; }  
    public Product Product { get; set; }
}