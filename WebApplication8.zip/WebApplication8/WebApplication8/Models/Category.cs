﻿using System.ComponentModel.DataAnnotations;
using WebApplication8.Models;

public class Category
{
    public int CategoryId { get; set; }
    [Required]
    public string Name { get; set; }
    public string? Description { get; set; }  
    public string? ImageUrl { get; set; }      
    public int SortOrder { get; set; } = 0;
    public bool IsActive { get; set; } = true;
    public ICollection<Product> Products { get; set; }
}