using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication8.Views.Orders
{
    public class OrderConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
