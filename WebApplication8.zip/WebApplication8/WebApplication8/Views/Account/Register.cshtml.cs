using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication8.Views.Account
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
