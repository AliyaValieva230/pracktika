using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication8.Views.Admin
{
    public class OrdersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
