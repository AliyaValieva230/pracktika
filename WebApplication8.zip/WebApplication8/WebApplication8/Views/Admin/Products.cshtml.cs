using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication8.Views.Admin
{
    public class ProductsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
